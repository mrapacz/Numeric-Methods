Programy napisane w języku Python 3.4.
$python main.py
Należy posiadać dostęp do biblioteki numpy oraz matplotlib i plotly.
