def func(x):
    return 3 * x + 2
